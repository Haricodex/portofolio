<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hari Priya | Portfolio</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
</head>

<body>
  <header>
    <div class="logo">Hari Priya</div>
    <nav>
      <ul>
        <li><a href="#about">About</a></li>
        <li><a href="#skills">Skills</a></li>
        <li><a href="#projects">Projects</a></li>
        <li><a href="#experience">Experience</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fab fa-telegram"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
      </div>
    </nav>
  </header>

  <section class="main">
    <div class="left">
      <h5>Hello,</h5>
      <h1>I'm Sriperambuduru Hari Priya</h1>
      <h3>Software Developer | CSE (IoT)</h3>
      <p>From India</p>
      <button>Contact Me</button>
    </div>
    <div class="right">
      <img src="4064a2d9-c216-43b8-9383-a22dbe13dd94.png" alt="Profile Photo" />
    </div>
  </section>

  <section id="about">
    <h2>About Me</h2>
    <p>I am currently a 2nd-year Computer Science and Engineering student at Shiv Nadar University Chennai, with a specialization in IoT. Passionate about building intelligent systems, full-stack development, and leveraging cloud and AI for social impact.</p>
  </section>

  <section id="skills">
    <h2>Technical Skills</h2>
    <ul>
      <li>Languages: C/C++, Python, Java, HTML, CSS</li>
      <li>Libraries/Tools: OpenCV, YOLOv8, NumPy, Flask, VS Code, Git</li>
      <li>Cloud/DB: MySQL, Firebase, AWS IoT</li>
      <li>Coursework: DS, OS, OOP, DBMS, CN, SE, IoT Edge, API Services</li>
      <li>Soft Skills: Problem Solving, Self-learning, Presentation, Adaptability</li>
    </ul>
  </section>

  <section id="projects">
    <h2>Projects</h2>
    <ul>
      <li><strong>Real-Time Health Monitoring:</strong> ESP32, Blynk IoT, LSTM, Cloud dashboards for patient data.</li>
      <li><strong>Fall Prevention System:</strong> Edge Impulse, TensorFlow Lite, MQTT, AWS IoT, emergency alerts via Bluetooth.</li>
      <li><strong>GLOF Early Warning System:</strong> Satellite data, AWS IoT, flood prediction using ML and web-based visualization.</li>
    </ul>
  </section>

  <section id="experience">
    <h2>Experience</h2>
    <p><strong>Software Development Intern @ Cognifyz Technologies</strong> (Aug 2023 – Present)<br>Working on game development, CRUD applications, web scraping, and full-stack development.</p>
  </section>

  <section id="contact">
    <h2>Contact</h2>
    <p>Email: hari23110324@snuchennai.edu.in    Phone: +91 81212 30532</p>
  </section>

  <footer>
    &copy; 2025 Hari Priya. All rights reserved.
  </footer>

  <script src="script.js"></script>
</body>

</html>
